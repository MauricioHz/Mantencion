<?php
echo 'equipo';
?>