<?php
echo 'area';
?>