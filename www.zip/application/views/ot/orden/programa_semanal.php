<style>
    .equipo{color: #0824bd;}
</style>
<div class="row">
    <div class="col-lg-10 col-lg-offset-1">
        <div class="panel panel-default">
            <div class="panel-heading">
                <p>Programa semanal</p>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="tabla-programa-semanal" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr> 		
                                <th>Anio</th>
                                <th>Semana</th>
                                <th>ID</th>
                                <th>Equipo</th>
                                <th>Actividad</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>