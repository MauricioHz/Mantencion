<div class="row">
	<div class="col-lg-12">
		<div class="bs-example" data-example-id="contextual-panels">
			<div class="panel panel-default"> 
<div class="panel-heading clearfix"> 
			<h3 class="panel-title pull-left" style="padding-top: 7.5px;">Crear orden de trabajo</h3> 
<div class="btn-group pull-right">
                    <a href="http://sistema.mobagricola.cl/index.php/mantenimiento/listar" class="btn btn-success btn-sm">Listar ordenes de trabajo</a>
                  </div>
			</div>
			 <div class="panel-body"> 
			 <p>En esta página se ingresarán datos para la orden de trabajo.</p>
                <form>
                     <button type="button" class="btn btn-success">Enviar datos</button>
                </form>
			 </div>
			  </div>
		</div>
	</div>
</div>