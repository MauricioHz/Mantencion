<div class="row">
    <div class="col-lg-12">
        <div class="bs-example" data-example-id="contextual-panels">
            <div class="panel panel-default"> <div class="panel-heading"> 
            <h3 class="panel-title">Registro de Apoyo Mantenciones</h3> 
            </div>
            <div class="panel-body">
                <p>En esta página se ingresarán datos para el registro de mantención.</p>
                <form>
                     <button type="button" class="btn btn-success">Enviar datos</button>
                </form>
             </div>
            </div>
        </div>
    </div>
</div>