<div class="row">
    <div class="col-lg-12">
        <div class="bs-example" data-example-id="contextual-panels">
            <div class="panel panel-default"> <div class="panel-heading"> 
            <h3 class="panel-title">Costos de mantenciones</h3> 
            </div>
            <div class="panel-body">
                <p>En esta página se visualizarán los costos de mantención.</p>
             </div>
            </div>
        </div>
    </div>
</div>