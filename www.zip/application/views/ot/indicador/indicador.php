<div class="row">
	<div class="col-lg-12">
		<div class="bs-example" data-example-id="contextual-panels">
			<div class="panel panel-default"> <div class="panel-heading"> 
			<h3 class="panel-title">Cumplimiento Programa de Mantención Preventivo</h3> 
			</div>
			 <div class="panel-body"> 
                             <p>En esta página se visualizará el indicador de gestión.</p>
                         </div>
			</div>
		</div>
	</div>
</div>