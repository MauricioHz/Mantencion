<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-12 01:05:00 --> Severity: Notice --> Undefined variable: resumen /home/santamar/public_html/sistema/application/views/ot/bienvenida.php 40
ERROR - 2017-05-12 01:05:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/santamar/public_html/sistema/application/views/ot/bienvenida.php 40
ERROR - 2017-05-12 01:07:25 --> Severity: Notice --> Undefined variable: resumen /home/santamar/public_html/sistema/application/views/ot/bienvenida.php 40
ERROR - 2017-05-12 01:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/santamar/public_html/sistema/application/views/ot/bienvenida.php 40
ERROR - 2017-05-12 01:07:29 --> 404 Page Not Found: Index/index
ERROR - 2017-05-12 01:08:35 --> 404 Page Not Found: Acceso/permiso
ERROR - 2017-05-12 01:15:39 --> Severity: Notice --> Undefined variable: resumen /home/santamar/public_html/sistema/application/views/ot/bienvenida.php 40
ERROR - 2017-05-12 01:15:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/santamar/public_html/sistema/application/views/ot/bienvenida.php 40
ERROR - 2017-05-12 01:17:10 --> 404 Page Not Found: Acceso/assets
ERROR - 2017-05-12 01:27:39 --> 404 Page Not Found: Mantenimiento/favicon.ico
ERROR - 2017-05-12 12:48:45 --> 404 Page Not Found: Assets/imagen
ERROR - 2017-05-12 12:48:45 --> 404 Page Not Found: Acceso/assets
ERROR - 2017-05-12 12:48:46 --> 404 Page Not Found: Acceso/assets
ERROR - 2017-05-12 12:48:46 --> 404 Page Not Found: Acceso/assets
ERROR - 2017-05-12 12:57:20 --> Severity: Notice --> Undefined variable: id /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 62
ERROR - 2017-05-12 12:57:20 --> Severity: Notice --> Undefined variable: semana /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 62
ERROR - 2017-05-12 12:57:20 --> Severity: Notice --> Undefined variable: id /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 71
ERROR - 2017-05-12 12:58:03 --> Severity: Notice --> Undefined variable: semana /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 62
ERROR - 2017-05-12 13:19:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-05-12 13:20:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-05-12 13:22:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-05-12 13:38:21 --> Severity: Notice --> Undefined variable: id_orden /home/santamar/public_html/sistema/application/controllers/Mantenimiento.php 442
ERROR - 2017-05-12 13:42:06 --> Severity: Parsing Error --> syntax error, unexpected ''(como fecha de intervención)' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 150
ERROR - 2017-05-12 13:42:38 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 144
ERROR - 2017-05-12 13:42:38 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 145
ERROR - 2017-05-12 13:42:38 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 146
ERROR - 2017-05-12 13:42:38 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 147
ERROR - 2017-05-12 13:42:38 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 148
ERROR - 2017-05-12 13:42:38 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 150
ERROR - 2017-05-12 13:42:38 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 151
ERROR - 2017-05-12 13:42:38 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 152
ERROR - 2017-05-12 13:43:49 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 144
ERROR - 2017-05-12 13:43:49 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 145
ERROR - 2017-05-12 13:43:49 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 146
ERROR - 2017-05-12 13:43:49 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 147
ERROR - 2017-05-12 13:43:49 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 148
ERROR - 2017-05-12 13:43:49 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 150
ERROR - 2017-05-12 13:43:49 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 151
ERROR - 2017-05-12 13:43:49 --> Severity: Notice --> Trying to get property of non-object /home/santamar/public_html/sistema/application/views/ot/orden/supervisor.php 152
ERROR - 2017-05-12 14:00:41 --> 404 Page Not Found: Mantenimiento/favicon.ico
ERROR - 2017-05-12 14:02:37 --> Severity: Notice --> Undefined index: semana /home/santamar/public_html/sistema/application/controllers/Mantenimiento.php 279
ERROR - 2017-05-12 14:02:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/santamar/public_html/sistema/application/controllers/Mantenimiento.php 279
ERROR - 2017-05-12 14:02:42 --> Severity: Notice --> Undefined variable: id_plan /home/santamar/public_html/sistema/application/views/ot/programa/detalle.php 255
ERROR - 2017-05-12 14:32:10 --> Severity: Notice --> Undefined variable: resumen /home/santamar/public_html/sistema/application/views/ot/bienvenida.php 40
ERROR - 2017-05-12 14:32:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/santamar/public_html/sistema/application/views/ot/bienvenida.php 40
ERROR - 2017-05-12 14:33:40 --> Severity: Notice --> Undefined variable: resumen /home/santamar/public_html/sistema/application/views/ot/bienvenida.php 40
ERROR - 2017-05-12 14:36:07 --> 404 Page Not Found: Acceso/assets
